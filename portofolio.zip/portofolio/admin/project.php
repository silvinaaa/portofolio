<?php
  include "header.php";
?>
<?php
  include "menu.php";
?>



<?php
    require 'functions.php';
    $user = mysqli_fetch_assoc($a);
    $about = mysqli_fetch_assoc($b);
    
    $project = data("SELECT * FROM project");
    
    if(isset($_POST["submit"])){
        
        if(tambah($_POST) > 0){
            echo "
            <script>
                alert('Data berhasil dikirim');
            </script>
            ";
        }
        else {
            echo "gagal terkirim";
        }
    }
?>
<div class="container-fluid px-2 px-md-4">
      <div class="row justify-content-center">
      </div>
      <div class="card card-body border-radius-xl mt-4 min-height-400">
            <div class="col-12 col-xl-4">
              <div class="card card-plain h-100">
                <div class="card-header pb-0 p-3">
                  <div class="row">
                    <div class="col-md-8 d-flex align-items-center">
                      <h6 class="mb-0">MY PROJECT</h6>
                    </div>
                    <div class="col-md-4 text-end">
                      <a href="javascript:;">
                        <i class="fas fa-user-edit text-secondary text-sm" data-bs-toggle="tooltip" data-bs-placement="top" title="Edit Profile"></i>
                      </a>
                    </div>
                  </div>
                </div>
<div class="container">
        <div class="row justify-content-center">
            
            <?php foreach($project as $pro){ ?>
            
            
         <div class="col-md-4 mb-3">
          <div class="card">
          <img src="v/<?=$pro["foto"];?>" class="card-img-top" alt="project1">
          <div class="card-body">
            <h2 class="display-6"><?=$pro["nama_p"];?></h2>
            <p class="card-text"><?=$pro["ket"];?></p>
           </div>
           </div>
          </div>
          <?php }?>
      </div>
      
          </div>
              </div>
             </div>
         </div>
      </div>
<?php
  include "footer.php";
?>
