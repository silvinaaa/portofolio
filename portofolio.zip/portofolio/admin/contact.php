<?php
  include "header.php";
?>
<?php
  include "menu.php";
?>

<div class="container-fluid px-2 px-md-4">
      <div class="row justify-content-center">
      </div>
      <div class="card card-body border-radius-xl mt-4 min-height-300">
          </div>
          </div>
<?php
  include "footer.php";
?>
